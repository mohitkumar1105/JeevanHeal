export { default as IMG01} from '../../../assets/images/blog-01.jpg';
export { default as IMG02} from '../../../assets/images/doctor-thumb-02.jpg';
export { default as IMG03 } from '../../../assets/images/patient4.jpg';
export { default as IMG04 } from '../../../assets/images/patient5.jpg';
export { default as IMG05 } from '../../../assets/images/patient3.jpg';
export { default as IMG06 } from '../../../assets/images/patient6.jpg';
export { default as IMG07 } from '../../../assets/images/patient7.jpg';
export {default as IMG08} from '../../../assets/images/doctors/doctor-thumb-01.jpg';
export {default as doctorthumb3} from '../../../assets/images/doctors/doctor-thumb-03.jpg';
export {default as doctorthumb4} from '../../../assets/images/doctors/doctor-thumb-04.jpg';
export {default as doctorthumb5} from '../../../assets/images/doctors/doctor-thumb-05.jpg';
export {default as doctorthumb6} from '../../../assets/images/doctors/doctor-thumb-06.jpg';
export {default as doctorthumb7} from '../../../assets/images/doctors/doctor-thumb-07.jpg';
export {default as doctorthumb8} from '../../../assets/images/doctors/doctor-thumb-08.jpg';
export {default as doctorthumb9} from '../../../assets/images/doctors/doctor-thumb-09.jpg';
export {default as doctorthumb10} from '../../../assets/images/doctors/doctor-thumb-10.jpg';
export {default as blog2} from '../../../assets/images/blog/blog-02.jpg'
export {default as blog3} from '../../../assets/images/blog/blog-03.jpg'
export {default as blog4} from '../../../assets/images/blog/blog-04.jpg'
export {default as blog5} from '../../../assets/images/blog/blog-05.jpg'
export {default as blog6} from '../../../assets/images/blog/blog-06.jpg'
export {default as blog7} from '../../../assets/images/blog/blog-07.jpg'
export {default as blog8} from '../../../assets/images/blog/blog-08.jpg'
export {default as blog9} from '../../../assets/images/blog/blog-09.jpg'
export {default as blog10} from '../../../assets/images/blog/blog-10.jpg'
export {default as img_1} from "../../../assets/images/img-01.jpg"
export {default as img_2} from "../../../assets/images/img-02.jpg"
export {default as img_3} from "../../../assets/images/img-03.jpg"

