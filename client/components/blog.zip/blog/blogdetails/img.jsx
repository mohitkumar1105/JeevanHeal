export { default as IMG01} from '../../../assets/images/blog/blog-01.jpg';
export { default as IMG02} from '../../../assets/images/doctors/doctor-thumb-02.jpg';
export { default as IMG03 } from '../../../assets/images/patients/patient4.jpg';
export { default as IMG04 } from '../../../assets/images/patients/patient5.jpg';
export { default as IMG05 } from '../../../assets/images/patients/patient3.jpg';
export { default as IMG06 } from '../../../assets/images/patients/patient6.jpg';
export { default as IMG07 } from '../../../assets/images/patients//patient7.jpg';