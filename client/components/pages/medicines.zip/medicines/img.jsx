
export { default as product8} from '../../../assets/images/products/product8.jpg';
export { default as product9} from '../../../assets/images/products/product9.jpg';
export { default as product10} from '../../../assets/images/products/product10.jpg';
export { default as product11} from '../../../assets/images/products/product11.jpg';
export { default as product12} from '../../../assets/images/products/product12.jpg';
export { default as product13} from '../../../assets/images/products/product13.jpg';
export { default as product14} from '../../../assets/images/products/product14.jpg';
export { default as product15} from '../../../assets/images/products/product15.jpg';

export { default as urology1} from './pic/1737_health-check.png';
export { default as urology2} from './pic/6484_dental-care.png';
export { default as urology3} from './pic/5226_DiabeticTestVer_2.png';
export { default as urology4} from './pic/1869_vaccination.png';
export { default as urology5} from './pic/3891_treatment-room.png';
export { default as urology6} from './pic/8190_health-at-home.png';
export { default as urology7} from './pic/8845_diagnostic.png';
export { default as urology8} from './pic/9281_Consultation.png';
export { default as urology9} from './pic/8190_health-at-home.png';
export { default as urology10} from './pic/3891_treatment-room.png';
export { default as speci1} from './pic/cough-cold-v1.jpg';
export { default as speci2} from './pic/depression-anxiety-v1.jpg';
export { default as speci3} from './pic/lose-weight-v1.jpg';
export { default as speci4} from './pic/skin-problems-v1 (1).jpg';
export { default as speci5} from './pic/period-problems-v1 (1).jpg';
export { default as speci6} from './pic/performance-issues-bed-v1.jpg';
export { default as speci7} from './pic/stomach-issues-v1.jpg';
export { default as speci8} from './pic/cough-cold-v1.jpg';
export { default as ourd1} from './pic/user-1.png';
export { default as ourd2} from './pic/user-2.png';
export { default as ourd3} from './pic/user-3.png';
export { default as ourd4} from './pic/user-1.png';
export { default as download} from './pic/app-download-banner-web.png';
export { default as sticker1} from './pic/play-store.png';
export { default as sticker2} from './pic/app-store.png';









