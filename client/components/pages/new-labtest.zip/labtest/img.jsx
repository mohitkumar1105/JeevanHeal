import { Category } from '@material-ui/icons';

export { default as CAT01} from '../../../assets/images/category/1.png';
export { default as CAT02} from '../../../assets/images/category/2.png';
export { default as CAT03} from '../../../assets/images/category/3.png';
export { default as CAT04} from '../../../assets/images/category/4.png';
export { default as CAT05} from '../../../assets/images/category/5.png';





