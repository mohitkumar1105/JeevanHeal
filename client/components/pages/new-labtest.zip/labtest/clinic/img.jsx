export { default as IMG01} from '../../../../assets/images/cancer.svg';
export { default as IMG02} from '../../../../assets/images/Bones.svg';
export { default as IMG03} from '../../../../assets/images/Fever.svg';
export { default as IMG04} from '../../../../assets/images/Diabetes.svg';
export { default as IMG05} from '../../../../assets/images/Skin.svg';
