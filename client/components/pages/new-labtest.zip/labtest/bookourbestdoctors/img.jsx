export { default as IMG01} from '../../../../assets/images/lab-img/vitamin-img.jpg';
export { default as IMG02} from '../../../../assets/images/lab-img/vitamin-img.jpg';
export { default as IMG03} from '../../../../assets/images/doctors/doctor-03.jpg';
export { default as IMG04} from '../../../../assets/images/doctors/doctor-04.jpg';
export { default as IMG05} from '../../../../assets/images/doctors/doctor-05.jpg';
export { default as IMG06} from '../../../../assets/images/doctors/doctor-06.jpg';
export { default as IMG07} from '../../../../assets/images/doctors/doctor-07.jpg';
export { default as IMG08} from '../../../../assets/images/doctors/doctor-08.jpg';
