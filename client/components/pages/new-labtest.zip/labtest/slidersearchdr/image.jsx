export { default as Slide1} from '../../../../assets/images/slidelab1.png';
export { default as Slide2} from '../../../../assets/images/slidelab2.png';